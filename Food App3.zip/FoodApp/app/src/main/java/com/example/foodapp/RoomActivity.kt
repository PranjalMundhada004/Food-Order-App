package com.example.foodapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import org.jetbrains.anko.doAsync
import org.jetbrains.anko.toast
import org.jetbrains.anko.uiThread
import java.util.*

class RoomActivity : AppCompatActivity() {
    private lateinit var mDb:RoomSingleton
    private val mRandom: Random = Random()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_room)

        mDb = RoomSingleton.getInstance(applicationContext)
        val textView = findViewById<TextView>(R.id.textView) as TextView
//        textView?.setOnClickListener{ Toast.makeText(this@MainActivity,
//            R.string.text_on_click, Toast.LENGTH_LONG).show() }
        // Make the text view scrollable
        textView.movementMethod = ScrollingMovementMethod()
        val btnInsert = findViewById<Button>(R.id.btnInsert) as Button

        val textView1 = findViewById<EditText>(R.id.textview1) as EditText
        val textView2 = findViewById<EditText>(R.id.textview2) as EditText
//        val textView3 = findViewById<TextView>(R.id.textView3) as TextView


        // Insert button click listener
        btnInsert.setOnClickListener{
            // Initialize a new student
            val student = Student(id = null,
//                fullName = UUID.randomUUID().toString(),
//                result = mRandom.nextInt(100)
                fullName = textView1.text.toString(),
                result = textView2.text.toString().toInt()
            )

            doAsync {
                // Put the student in database
                mDb.studentDao().insert(student)

                uiThread {
                    toast("One record inserted.")
                }
            }
        }

        val btnSelect = findViewById<Button>(R.id.btnSelect) as Button

        // Select button click listener
        btnSelect.setOnClickListener{
            doAsync {
                // Get the student list from database
                val list = mDb.studentDao().allStudents()

                uiThread {
                    toast("${list.size} records found.")
                    // Display the students in text view
                    textView.text = ""
                    for (student in list){
                        textView.append("${student.id} : ${student.fullName} : ${student.result}\n")
                    }
                }
            }
        }
    }


}