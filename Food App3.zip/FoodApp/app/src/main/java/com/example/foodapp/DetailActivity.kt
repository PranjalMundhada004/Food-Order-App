package com.example.foodapp

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

import android.widget.Button
import androidx.annotation.RequiresApi
import com.example.foodapp.databinding.ActivityDetailBinding
import com.example.foodapp.EndActivity


class DetailActivity : AppCompatActivity() {

    lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val image = intent.getIntExtra("image",0)
        val price = intent.getStringExtra("price")?.toInt()
        val name = intent.getStringExtra("name")
        val description = intent.getStringExtra("description")

        binding.detailImage.setImageResource(image);
        binding.priceLbl.setText(String.format("%d",price));
        binding.nameBox.setText(name);
        binding.detailDescription.setText(description);

    }


    val button_end = findViewById<Button>(R.id.button_end) as Button
    fun next_activity(view: android.view.View) {
        val intent3 = Intent(this,EndActivity::class.java)
        startActivity(intent3)
    }


}