package com.example.foodapp

//class OrderActivity {
//}
//
//package com.example.foodorderapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.foodapp.OrdersAdapter
import com.example.foodapp.MainModel
import com.example.foodapp.OrdersModel
import com.example.foodapp.databinding.ActivityMainBinding
import com.example.foodapp.databinding.ActivityOrderBinding

class OrderActivity : AppCompatActivity() {

    lateinit var binding: ActivityOrderBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOrderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var list = ArrayList<OrdersModel>()

        list.add(OrdersModel(R.drawable.burger , "Cheese Burger" , "160" , "23345"))
        list.add(OrdersModel(R.drawable.burger , "Cheese Burger" , "160" , "23345"))
        list.add(OrdersModel(R.drawable.burger , "Cheese Burger" , "160" , "23345"))
        list.add(OrdersModel(R.drawable.burger , "Cheese Burger" , "160" , "23345"))
        list.add(OrdersModel(R.drawable.burger , "Cheese Burger" , "160" , "23345"))
        list.add(OrdersModel(R.drawable.burger , "Cheese Burger" , "160" , "23345"))
        list.add(OrdersModel(R.drawable.burger , "Cheese Burger" , "160" , "23345"))
        list.add(OrdersModel(R.drawable.burger , "Cheese Burger" , "160" , "23345"))
        list.add(OrdersModel(R.drawable.burger , "Cheese Burger" , "160" , "23345"))
        list.add(OrdersModel(R.drawable.burger , "Cheese Burger" , "160" , "23345"))




    }
}