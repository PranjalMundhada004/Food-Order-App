//package com.example.foodapp
//
//import android.content.Intent
//import android.os.Build
//import androidx.appcompat.app.AppCompatActivity
//import android.os.Bundle
//import android.view.View
//import android.widget.Button
//import android.widget.ImageView
//import androidx.annotation.RequiresApi
//import androidx.recyclerview.widget.LinearLayoutManager
//import androidx.recyclerview.widget.RecyclerView
//import com.example.foodapp.databinding.ActivityOrderListBinding
//import com.example.foodapp.DetailActivity
//import android.media.Image as Image
//
////import android.content.Intent
////import androidx.appcompat.app.AppCompatActivity
////import android.os.Bundle
////import android.view.View
////import android.widget.Button
////import androidx.recyclerview.widget.LinearLayoutManager
////import androidx.recyclerview.widget.RecyclerView
////import com.example.foodapp.databinding.ActivityMainBinding
//
//class OrderList : AppCompatActivity() {
//    lateinit var binding: ActivityOrderListBinding
//    @RequiresApi(Build.VERSION_CODES.KITKAT)
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_order_list)
//        binding = ActivityOrderListBinding.inflate(layoutInflater)
//        setContentView(binding.root)
//
//
//        var list = ArrayList<MainModel>()
//
//        val abc = findViewById<View>(R.id.recyclerview1) as RecyclerView
//
//        list.add(
//            MainModel(
//                R.drawable.burger,
//                "Cheese Burger",
//                "160",
//                "Chicken Burger with extra cheese"
//            )
//        )
//        list.add(
//            MainModel(
//                R.drawable.pizza,
//                "Pizza",
//                "130",
//                "Cheese loaded pizza with tomatoes, olives and mushrooms as toppings"
//            )
//        )
//        list.add(MainModel(R.drawable.sandwich, "Sandwich", "75", "Plain grilled sandwich"))
//        list.add(
//            MainModel(
//                R.drawable.cheese_french_fries,
//                "Cheesy French Fries",
//                "60",
//                "Cheesy french fires"
//            )
//        )
//        list.add(MainModel(R.drawable.momos, "Momo", "90", "Delicious momo with chutney"))
//        list.add(MainModel(R.drawable.noodles, "Noodles", "80", "Tasty Chinese Noodles"))
//        list.add(
//            MainModel(
//                R.drawable.donuts,
//                "Donuts",
//                "60",
//                "Yummy Donuts with 4 variety of toppings"
//            )
//        )
//
//        var adapter = MainAdapter(list, this)
//        abc.adapter = adapter;
//
//        var layoutManager = LinearLayoutManager(this)
//        //RecyclerView.LayoutManager = LinearLayoutManager
//        abc.layoutManager = LinearLayoutManager(this)
//
//        val imageView = findViewById<Button>(R.id.imageView) as ImageView
//        fun prev_activity(view: android.view.View) {
//            val intent2 = Intent(this,DetailActivity::class.java)
//            startActivity(intent2)
//        }
//
//
//    }
//}