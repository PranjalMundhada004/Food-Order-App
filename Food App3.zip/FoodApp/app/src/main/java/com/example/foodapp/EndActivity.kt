package com.example.foodapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class EndActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_end)

        val intentValue = intent.getStringExtra("Data")
        findViewById<TextView>(R.id.endtext).apply{
            text = intentValue.toString()
        }
    }
}